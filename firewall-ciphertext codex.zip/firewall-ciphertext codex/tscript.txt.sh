#!/bin/bash

KEY="0123456789abcdef0123456789abcdef0123456789abcdef"
IV="abcdef0123456789abcdef0123456789"

echo "Creating 128-byte text file..."
echo -n "MASOOabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" > 128bytes.txt
echo "File '128bytes.txt' created successfully!"

echo "Encrypting file using AES-192..."

openssl enc -aes-192-ecb -e -K $KEY -nopad -in 128bytes.txt -out ecb_cipher.bin
openssl enc -aes-192-cbc -e -K $KEY -iv $IV -nopad -in 128bytes.txt -out cbc_cipher.bin
openssl enc -aes-192-cfb -e -K $KEY -iv $IV -nopad -in 128bytes.txt -out cfb_cipher.bin
openssl enc -aes-192-ofb -e -K $KEY -iv $IV -nopad -in 128bytes.txt -out ofb_cipher.bin

echo "Encryption done."
echo "Displaying ciphertexts before modification:"
xxd ecb_cipher.bin
xxd cbc_cipher.bin
xxd cfb_cipher.bin
xxd ofb_cipher.bin

#46
echo "Modifying the 46th byte in each ciphertext file..."
dd if=ecb_cipher.bin of=ecb_corrupt.bin bs=1 count=45 2>/dev/null
echo -n -e "\xAA" >> ecb_corrupt.bin
dd if=ecb_cipher.bin of=tmp.bin bs=1 skip=46 2>/dev/null
cat tmp.bin >> ecb_corrupt.bin

dd if=cbc_cipher.bin of=cbc_corrupt.bin bs=1 count=45 2>/dev/null
echo -n -e "\xAA" >> cbc_corrupt.bin
dd if=cbc_cipher.bin of=tmp.bin bs=1 skip=46 2>/dev/null
cat tmp.bin >> cbc_corrupt.bin

dd if=cfb_cipher.bin of=cfb_corrupt.bin bs=1 count=45 2>/dev/null
echo -n -e "\xAA" >> cfb_corrupt.bin
dd if=cfb_cipher.bin of=tmp.bin bs=1 skip=46 2>/dev/null
cat tmp.bin >> cfb_corrupt.bin

dd if=ofb_cipher.bin of=ofb_corrupt.bin bs=1 count=45 2>/dev/null
echo -n -e "\xAA" >> ofb_corrupt.bin
dd if=ofb_cipher.bin of=tmp.bin bs=1 skip=46 2>/dev/null
cat tmp.bin >> ofb_corrupt.bin

echo "Byte modification done."

#16byte
BLOCK_START=$(( (86/16) * 16 ))
echo "Removing 16-byte block containing the 86th byte..."

dd if=ecb_corrupt.bin bs=1 count=$BLOCK_START of=ecb_corrupt_final.bin 2>/dev/null
dd if=ecb_corrupt.bin bs=1 skip=$((BLOCK_START+16)) of=tmp.bin 2>/dev/null
cat tmp.bin >> ecb_corrupt_final.bin

dd if=cbc_corrupt.bin bs=1 count=$BLOCK_START of=cbc_corrupt_final.bin 2>/dev/null
dd if=cbc_corrupt.bin bs=1 skip=$((BLOCK_START+16)) of=tmp.bin 2>/dev/null
cat tmp.bin >> cbc_corrupt_final.bin

dd if=cfb_corrupt.bin bs=1 count=$BLOCK_START of=cfb_corrupt_final.bin 2>/dev/null
dd if=cfb_corrupt.bin bs=1 skip=$((BLOCK_START+16)) of=tmp.bin 2>/dev/null
cat tmp.bin >> cfb_corrupt_final.bin

dd if=ofb_corrupt.bin bs=1 count=$BLOCK_START of=ofb_corrupt_final.bin 2>/dev/null
dd if=ofb_corrupt.bin bs=1 skip=$((BLOCK_START+16)) of=tmp.bin 2>/dev/null
cat tmp.bin >> ofb_corrupt_final.bin
echo "Block removal completed."
echo "Decrypting corrupted files..."
openssl enc -aes-192-ecb -d -K $KEY -nopad -in ecb_corrupt_final.bin -out ecb_decrypted.txt
openssl enc -aes-192-cbc -d -K $KEY -iv $IV -nopad -in cbc_corrupt_final.bin -out cbc_decrypted.txt
openssl enc -aes-192-cfb -d -K $KEY -iv $IV -nopad -in cfb_corrupt_final.bin -out cfb_decrypted.txt
openssl enc -aes-192-ofb -d -K $KEY -iv $IV -nopad -in ofb_corrupt_final.bin -out ofb_decrypted.txt
echo "Decryption completed."
# Display results
echo "Decryption results:"
echo "ECB Mode:"
cat ecb_decrypted.txt
echo "-------------------------"
echo "CBC Mode:"
cat cbc_decrypted.txt
echo "-------------------------"
echo "CFB Mode:"
cat cfb_decrypted.txt
echo "-------------------------"
echo "OFB Mode:"
cat ofb_decrypted.txt
echo "-------------------------"
echo "enddddd."