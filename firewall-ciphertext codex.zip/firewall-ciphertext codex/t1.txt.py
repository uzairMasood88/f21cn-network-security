import numpy as np
from collections import Counter

def compute_mr(column_text):
    L = len(column_text)
    if L < 2:
        return 0  

    #Counting the frequency of each letter
    freqs = Counter(column_text)
    fi_values = np.array(list(freqs.values()))
    #Computing MR
    MR = np.sum(fi_values * (fi_values - 1)) / (L * (L - 1))
    return MR

def analyze_vigenere_cipher(ciphertext, key_lengths):
    ciphertext = ''.join(filter(str.isalpha, ciphertext)).upper()  #Keeping only thee letters
    results = {}

    for key_length in key_lengths:
        columns = ['' for _ in range(key_length)]

        #Distribute characters into columns
        for i, letter in enumerate(ciphertext):
            columns[i % key_length] += letter

        #Compute MR for each column and then take the average
        mr_values = [compute_mr(col) for col in columns if len(col) > 1]  
        avg_mr = sum(mr_values) / len(mr_values) if mr_values else 0
        results[key_length] = avg_mr

    return results

#Reading ciphertext from our file
with open("ciphertext.txt", "r", encoding="utf-8") as file:
    ciphertext = file.read().strip()
#Defining key lengths to analyze as mentioned in our question
key_lengths = [4, 5, 6]
#Computing MR for the given key lengths
mr_results = analyze_vigenere_cipher(ciphertext, key_lengths)
#Displaying results
print("\n(((((<- Vigenère Cipher Key Length Analysis ->))))))")
print("\nMeasure of Roughness for given key lengths:")
for length, mr in mr_results.items():
    print(f"Key Length {length}: MR = {mr:.4f}")
#Finding the most likely key length based on closeness to 0.0686
best_guess = min(mr_results, key=lambda k: abs(mr_results[k] - 0.0686))
print(f"\nMost likely key length: {best_guess}")
